var urlServices = {
    serviceTest:{
        url:'http://10.106.12.66/geoapps/geo001/www/php/test.php',
        //url:'http://localhost/geoapps/geo001/www/php/test.php',
        type: 'GET'
    },
    serviceTestPOST:{
        url:'http://10.106.12.66/geoapps/geo001/www/php/test.php',
        //url:'http://localhost/geoapps/geo001/www/php/test.php',
        type: 'POST'
    }
    
    /*serviceTipoMembresia:{
        url: 'data/php/tipoMembresia.php',
        type: 'POST'
    },
    serviceBusqueda:{
        //url:'http://localhost:8080/vinom/site/dist/data/php/Busqueda.php',
		url: 'data/php/Busqueda.php',
        type: 'POST'
    },
	serviceMngFavoritos:{
		url: 'data/php/Favoritos.php',
        type: 'POST'
	},
	serviceToque:{
		url: 'data/php/Toque.php',
        type: 'POST'
	},
	serviceParties:{
		url: 'data/php/Parties.php',
        type: 'POST'
	},
    serviceAmiguis:{
        url: 'data/php/Amiguis.php',
        type: 'POST'
    },
    serviceInvitar:{
        url: 'data/php/Invitar.php',
        type: 'POST'
    },  
    preReg:{
        url: '../php/preReg.php',
        type: 'POST'
    }*/
   

};
